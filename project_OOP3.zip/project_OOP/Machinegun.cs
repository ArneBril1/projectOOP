﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace project_OOP
{
    public class MachineGun : Weapon
    {
        public MachineGun() : base(5, 1000)
        {
        }

        public override void Fire(Canvas canvas, double x, double y)
        {
            if (CanFire())
            {
                Image bullet = new Image();
                bullet.Source = new BitmapImage(new Uri("/bullet.png", UriKind.Relative));
                bullet.Width = 10;
                bullet.Height = 10;
                Canvas.SetTop(bullet, y - bullet.Height);
                Canvas.SetLeft(bullet, x - bullet.Width / 2);
                canvas.Children.Add(bullet);

                lastFired = DateTime.Now;
            }
        }
    }
}
