﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Newtonsoft.Json;

namespace project_OOP
{
    public partial class MainWindow : Window
    {
        private int score;
        private Random random = new Random();
        private List<Image> enemies = new List<Image>();
        private DispatcherTimer enemyTimer = new DispatcherTimer();
        private int maxEnemies = 6; 
        private const string HighScoreFileName = "highscore.json";
        private int highScore;
        private Weapon currentWeapon;
        private Pistol pistol;
        private MachineGun machineGun;
        private DispatcherTimer timer;
        private bool isMoving = false;
        private double horizontalDistance = 15;
        private double verticalDistance = 15;
        private double diagonalDistance = 10;

        private int LoadHighScore()
        {
            if (File.Exists(HighScoreFileName))
            {
                string json = File.ReadAllText(HighScoreFileName);
                return JsonConvert.DeserializeObject<int>(json);
            }
            return 0;
        }

        private void SaveHighScore(int highScore)
        {
            string json = JsonConvert.SerializeObject(highScore);
            File.WriteAllText(HighScoreFileName, json);
        }
        public MainWindow()
        {
            InitializeComponent();
            this.KeyDown += new KeyEventHandler(Timer_Tick);
            enemyTimer.Interval = TimeSpan.FromMilliseconds(25);
            enemyTimer.Tick += EnemyTimer_Tick;
            enemyTimer.Start();

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(20);
            timer.Tick += Timer_Tick;
            timer.Start();

            highScore = LoadHighScore();
            highScoreTextBlock.Text = "High Score: " + highScore;
            this.WindowState = WindowState.Maximized;

            pistol = new Pistol();
            machineGun = new MachineGun();
            currentWeapon = pistol;
        }

        private void EnemyTimer_Tick(object sender, EventArgs e)
        {
            if (enemies.Count < maxEnemies) 
            {
                Image enemy = new Image();
                enemy.Source = new BitmapImage(new Uri("/enemy.png", UriKind.Relative));
                enemy.Width = 45;
                enemy.Height = 45;
                Canvas.SetTop(enemy, 0);
                Canvas.SetLeft(enemy, random.Next(0, (int)(canvas.ActualWidth - enemy.Width)));
                canvas.Children.Add(enemy);
                enemies.Add(enemy);
            }

            foreach (var enemyImage in enemies)
            {
                Canvas.SetTop(enemyImage, Canvas.GetTop(enemyImage) + 2); 
            }

            CheckCollisions();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            // Beweeg de spaceship in de huidige richting
            if (Keyboard.IsKeyDown(Key.Left) && Canvas.GetLeft(spaceship) > 0)
                Canvas.SetLeft(spaceship, Canvas.GetLeft(spaceship) - 7);
            if (Keyboard.IsKeyDown(Key.Right) && Canvas.GetLeft(spaceship) < canvas.ActualWidth - spaceship.ActualWidth)
                Canvas.SetLeft(spaceship, Canvas.GetLeft(spaceship) + 7);
            if (Keyboard.IsKeyDown(Key.Up) && Canvas.GetTop(spaceship) > 0)
                Canvas.SetTop(spaceship, Canvas.GetTop(spaceship) - 7);
            if (Keyboard.IsKeyDown(Key.Down) && Canvas.GetTop(spaceship) < canvas.ActualHeight - spaceship.ActualHeight)
                Canvas.SetTop(spaceship, Canvas.GetTop(spaceship) + 7);

            if (Keyboard.IsKeyDown(Key.Up) && Keyboard.IsKeyDown(Key.Left))
            {
                if (Canvas.GetTop(spaceship) > 0 && Canvas.GetLeft(spaceship) > 0)
                {
                    Canvas.SetTop(spaceship, Canvas.GetTop(spaceship) - 5);
                    Canvas.SetLeft(spaceship, Canvas.GetLeft(spaceship) - 5);
                }
            }
            else if (Keyboard.IsKeyDown(Key.Up) && Keyboard.IsKeyDown(Key.Right))
            {
                if (Canvas.GetTop(spaceship) > 0 && Canvas.GetLeft(spaceship) < canvas.ActualWidth - spaceship.ActualWidth)
                {
                    Canvas.SetTop(spaceship, Canvas.GetTop(spaceship) - 5);
                    Canvas.SetLeft(spaceship, Canvas.GetLeft(spaceship) + 5);
                }
            }
            else if (Keyboard.IsKeyDown(Key.Down) && Keyboard.IsKeyDown(Key.Left))
            {
                if (Canvas.GetTop(spaceship) < canvas.ActualHeight - spaceship.ActualHeight && Canvas.GetLeft(spaceship) > 0)
                {
                    Canvas.SetTop(spaceship, Canvas.GetTop(spaceship) + 5);
                    Canvas.SetLeft(spaceship, Canvas.GetLeft(spaceship) - 5);
                }
            }
            else if (Keyboard.IsKeyDown(Key.Down) && Keyboard.IsKeyDown(Key.Right))
            {
                if (Canvas.GetTop(spaceship) < canvas.ActualHeight - spaceship.ActualHeight && Canvas.GetLeft(spaceship) < canvas.ActualWidth - spaceship.ActualWidth)
                {
                    Canvas.SetTop(spaceship, Canvas.GetTop(spaceship) + 5);
                    Canvas.SetLeft(spaceship, Canvas.GetLeft(spaceship) + 5);
                }
            }

            CheckCollisions();
        }

        private void CheckCollisions()
        {
            foreach (Image enemy in enemies)
            {
                if (Canvas.GetTop(enemy) > canvas.ActualHeight)
                {
                    canvas.Children.Remove(enemy);
                    enemies.Remove(enemy);
                    score++;
                    scoreTextBlock.Text = "Score: " + score;
                    break;
                }

                Rect spaceshipRect = new Rect(Canvas.GetLeft(spaceship), Canvas.GetTop(spaceship), 20, 15);
                Rect enemyRect = new Rect(Canvas.GetLeft(enemy), Canvas.GetTop(enemy), enemy.ActualWidth, enemy.ActualHeight);

                if (spaceshipRect.IntersectsWith(enemyRect))
                {
                    GameOver();
                    break;
                }
            }

        }

        private void GameOver()
        {
            enemyTimer.Stop();
            MessageBox.Show("Game Over. Your Score is " + score);

            if (score > highScore)
            {
                highScore = score;
                SaveHighScore(highScore);
                highScoreTextBlock.Text = "High Score: " + highScore;
            }
        }
    }
}