﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Newtonsoft.Json;

namespace project_OOP
{
    public partial class MainWindow : Window
    {
        private int score;
        private Random random = new Random();
        private List<Image> enemies = new List<Image>();
        private DispatcherTimer enemyTimer = new DispatcherTimer();
        private int maxEnemies = 8;
        private const string HighScoreFileName = "highscore.json";
        private int highScore;
        private Weapon currentWeapon;
        private Shotgun shotgun;
        private MachineGun machineGun;
        private DispatcherTimer timer;
        private bool isGameOver = false;
        int[] enemyStartPositions = { 50, 100, 150, 200, 250, 300, 350, 400, 450, 500 };
        private double enemySpeed = 1.0;
        public MainWindow()
        {
            try
            {
                InitializeComponent();
                this.KeyDown += new KeyEventHandler(Timer_Tick);
                enemyTimer.Interval = TimeSpan.FromMilliseconds(20);
                enemyTimer.Tick += EnemyTimer_Tick;
                enemyTimer.Start();
                this.KeyDown += new KeyEventHandler(Window_KeyDown);

                timer = new DispatcherTimer();
                timer.Interval = TimeSpan.FromMilliseconds(20);
                timer.Tick += Timer_Tick;
                timer.Start();

                // Load high score
                highScore = LoadHighScore();
                highScoreTextBlock.Text = "High Score: " + highScore;

                // Initialize weapons
                shotgun = new Shotgun();
                machineGun = new MachineGun();
                currentWeapon = shotgun;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Er is een fout opgetreden bij het initialiseren van het spel: " + ex.Message);
            }
        }

        private int LoadHighScore()
        {
            try
            {
                if (File.Exists(HighScoreFileName))
                {
                    string json = File.ReadAllText(HighScoreFileName);
                    return JsonConvert.DeserializeObject<int>(json);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Er is een fout opgetreden bij het laden van de high score: " + ex.Message);
            }
            return 0; 
        }

        private void SaveHighScore(int highScore)
        {
            try
            {
                string json = JsonConvert.SerializeObject(highScore);
                File.WriteAllText(HighScoreFileName, json);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Er is een fout opgetreden bij het opslaan van de high score: " + ex.Message);
            }
        }

        private void EnemyTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                // Spawn enemies
                if (enemies.Count < maxEnemies)
                {
                    Image enemy = new Image();
                    enemy.Source = new BitmapImage(new Uri("/enemy.png", UriKind.Relative));
                    enemy.Width = 45;
                    enemy.Height = 45;

                    // Willekeurig een startpositie selecteren uit de array
                    int randomStartPositionIndex = random.Next(0, enemyStartPositions.Length);
                    int randomStartPosition = enemyStartPositions[randomStartPositionIndex];

                    Canvas.SetTop(enemy, 0);
                    Canvas.SetLeft(enemy, randomStartPosition);
                    canvas.Children.Add(enemy);
                    enemies.Add(enemy);
                }

                // Move enemies 
                foreach (var enemyImage in enemies)
                {
                    Canvas.SetTop(enemyImage, Canvas.GetTop(enemyImage) + enemySpeed);

                    // versnelling
                    if (enemySpeed < 25)
                    {
                        enemySpeed += 0.001;
                    }
                }

                CheckCollisions();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Er is een fout opgetreden bij het initialiseren van het spel: " + ex.Message);
            }
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            if (!isGameOver)

            {
                if (Keyboard.IsKeyDown(Key.Left) && Canvas.GetLeft(spaceship) > 0)
                {
                    Canvas.SetLeft(spaceship, Canvas.GetLeft(spaceship) - 3);
                }
                if (Keyboard.IsKeyDown(Key.Right) && Canvas.GetLeft(spaceship) < canvas.ActualWidth - spaceship.ActualWidth)
                {
                    Canvas.SetLeft(spaceship, Canvas.GetLeft(spaceship) + 3);
                }
                if (Keyboard.IsKeyDown(Key.Up) && Canvas.GetTop(spaceship) > 0)
                {
                    Canvas.SetTop(spaceship, Canvas.GetTop(spaceship) - 3);
                }
                if (Keyboard.IsKeyDown(Key.Down) && Canvas.GetTop(spaceship) < canvas.ActualHeight - spaceship.ActualHeight)
                {
                    Canvas.SetTop(spaceship, Canvas.GetTop(spaceship) + 3);
                }

                // diagonaal bewegen
                if (Keyboard.IsKeyDown(Key.Up) && Keyboard.IsKeyDown(Key.Left))
                {
                    if (Canvas.GetTop(spaceship) > 0 && Canvas.GetLeft(spaceship) > 0)
                    {
                        Canvas.SetTop(spaceship, Canvas.GetTop(spaceship) - 2);
                        Canvas.SetLeft(spaceship, Canvas.GetLeft(spaceship) - 2);
                    }
                }
                else if (Keyboard.IsKeyDown(Key.Up) && Keyboard.IsKeyDown(Key.Right))
                {
                    if (Canvas.GetTop(spaceship) > 0 && Canvas.GetLeft(spaceship) < canvas.ActualWidth - spaceship.ActualWidth)
                    {
                        Canvas.SetTop(spaceship, Canvas.GetTop(spaceship) - 2);
                        Canvas.SetLeft(spaceship, Canvas.GetLeft(spaceship) + 2);
                    }
                }
                else if (Keyboard.IsKeyDown(Key.Down) && Keyboard.IsKeyDown(Key.Left))
                {
                    if (Canvas.GetTop(spaceship) < canvas.ActualHeight - spaceship.ActualHeight && Canvas.GetLeft(spaceship) > 0)
                    {
                        Canvas.SetTop(spaceship, Canvas.GetTop(spaceship) + 2);
                        Canvas.SetLeft(spaceship, Canvas.GetLeft(spaceship) - 2);
                    }
                }
                else if (Keyboard.IsKeyDown(Key.Down) && Keyboard.IsKeyDown(Key.Right))
                {
                    if (Canvas.GetTop(spaceship) < canvas.ActualHeight - spaceship.ActualHeight && Canvas.GetLeft(spaceship) < canvas.ActualWidth - spaceship.ActualWidth)
                    {
                        Canvas.SetTop(spaceship, Canvas.GetTop(spaceship) + 2);
                        Canvas.SetLeft(spaceship, Canvas.GetLeft(spaceship) + 2);
                    }
                }
            }
            CheckCollisions();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (!isGameOver)
            {
                try
                {

                    // wapen schieten bij de positie van het schip
                    if (e.Key == Key.Space)
                    {
                        currentWeapon.Fire(canvas, Canvas.GetLeft(spaceship) + spaceship.Width / 2, Canvas.GetTop(spaceship));
                    }

                    // switchen van wapens
                    if (e.Key == Key.D1) // "&" 
                    {
                        currentWeapon = new Shotgun();
                    }
                    else if (e.Key == Key.D2) // "é" 
                    {
                        currentWeapon = new MachineGun();
                    }
                }

                catch (Exception ex)
                {
                    Console.WriteLine("Er is een fout opgetreden bij het initialiseren van het spel: " + ex.Message);
                }
            }
        }
        private void CheckCollisions()
        {
            try
            {
                List<Image> enemiesToRemove = new List<Image>();
                List<Image> bulletsToRemove = new List<Image>();

                // botsing enemies 
                for (int i = 0; i < enemies.Count; i++)
                {
                    Image enemy = enemies[i];

                    // enemys uit het scherm verwijderen
                    if (Canvas.GetTop(enemy) > canvas.ActualHeight)
                    {
                        enemiesToRemove.Add(enemy);
                        score++;
                        scoreTextBlock.Text = "Score: " + score;
                    }

                    // kogels tegen vijanden
                    Rect spaceshipRect = new Rect(Canvas.GetLeft(spaceship), Canvas.GetTop(spaceship), 20, 15);
                    Rect enemyRect = new Rect(Canvas.GetLeft(enemy), Canvas.GetTop(enemy), enemy.ActualWidth, enemy.ActualHeight);

                    foreach (var bullet in canvas.Children.OfType<Image>().Where(x => x.Source.ToString().Contains("bullet.png")).ToList())
                    {
                        Rect bulletRect = new Rect(Canvas.GetLeft(bullet), Canvas.GetTop(bullet), bullet.ActualWidth, bullet.ActualHeight);

                        if (bulletRect.IntersectsWith(enemyRect))
                        {
                            bulletsToRemove.Add(bullet);
                            enemiesToRemove.Add(enemy);
                            score++;
                            scoreTextBlock.Text = "Score: " + score;
                        }
                    }
                    // botsing vijanden en speler
                    if (spaceshipRect.IntersectsWith(enemyRect))
                    {
                        GameOver();
                    }
                }
                // verwijder kogels en vijanden die gebotst hebben
                foreach (Image enemyToRemove in enemiesToRemove)
                {
                    canvas.Children.Remove(enemyToRemove);
                    enemies.Remove(enemyToRemove);
                }

                foreach (Image bulletToRemove in bulletsToRemove)
                {
                    canvas.Children.Remove(bulletToRemove);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Er is een fout opgetreden bij het initialiseren van het spel: " + ex.Message);
            }
        }
        private void GameOver()
        {
            try
            {
                // stop het spel en toon de knoppen
                isGameOver = true;
                enemyTimer.Stop();
                restartButton.Visibility = Visibility.Visible;
                closeButton.Visibility = Visibility.Visible;

                // update score textblock
                scoreTextBlock.Text = "Game Over! Your Score is " + score;

                // update highscore als nodig is
                if (score > highScore)
                {
                    highScore = score;
                    SaveHighScore(highScore);
                    highScoreTextBlock.Text = "High Score: " + highScore;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Er is een fout opgetreden bij het einde van het spel: " + ex.Message);
            }
        }
        private void RestartButton_Click(object sender, RoutedEventArgs e)
        {
            // Restart the game
            RestartGame();
            isGameOver = false;
            // Hide the restart and close buttons
            restartButton.Visibility = Visibility.Collapsed;
            closeButton.Visibility = Visibility.Collapsed;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
        private void RestartGame()
        {
            try
            {
                // Reset the score and remove all enemies and bullets
                score = 0;
                scoreTextBlock.Text = "Score: " + score;
                enemySpeed = 1.0;

                for (int i = 0; i < enemies.Count; i++)
                {
                    Image enemy = enemies[i];
                    canvas.Children.Remove(enemy);
                    enemies.Remove(enemy);
                    i--;
                }

                foreach (var bullet in canvas.Children.OfType<Image>().Where(x => x.Source.ToString().Contains("bullet.png")).ToList())
                {
                    canvas.Children.Remove(bullet);
                }

                // Reset the spaceship position and restart the enemy timer
                Canvas.SetLeft(spaceship, 295);
                Canvas.SetTop(spaceship, 400);
                enemyTimer.Start();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Er is een fout opgetreden bij het herstarten van het spel: " + ex.Message);
            }
        }
    }
}