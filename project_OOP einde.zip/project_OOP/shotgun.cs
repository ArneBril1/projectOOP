﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace project_OOP
{
    public class Shotgun : Weapon
    {
        public Shotgun() : base(1500)
        {
        }

        public override void Fire(Canvas canvas, double x, double y)
        {
            try
            {
                if (CanFire())
                {
                    // 3 kogels maken
                    Image bullet1 = new Image();
                    bullet1.Source = new BitmapImage(new Uri("/bullet.png", UriKind.Relative));
                    bullet1.Width = 10;
                    bullet1.Height = 10;
                    Canvas.SetTop(bullet1, y - bullet1.Height);
                    Canvas.SetLeft(bullet1, x - bullet1.Width / 2);
                    canvas.Children.Add(bullet1);

                    Image bullet2 = new Image();
                    bullet2.Source = new BitmapImage(new Uri("/bullet.png", UriKind.Relative));
                    bullet2.Width = 10;
                    bullet2.Height = 10;
                    Canvas.SetTop(bullet2, y - bullet2.Height - 20);
                    Canvas.SetLeft(bullet2, x - bullet2.Width / 2 - 30);
                    canvas.Children.Add(bullet2);

                    Image bullet3 = new Image();
                    bullet3.Source = new BitmapImage(new Uri("/bullet.png", UriKind.Relative));
                    bullet3.Width = 10;
                    bullet3.Height = 10;
                    Canvas.SetTop(bullet3, y - bullet3.Height - 20);
                    Canvas.SetLeft(bullet3, x - bullet3.Width / 2 + 30);
                    canvas.Children.Add(bullet3);

                    lastFired = DateTime.Now;

                    // bewegen kogels 
                    DispatcherTimer bulletTimer = new DispatcherTimer();
                    bulletTimer.Interval = TimeSpan.FromMilliseconds(20);
                    bulletTimer.Tick += (sender, args) =>
                    {
                        Canvas.SetTop(bullet1, Canvas.GetTop(bullet1) - 10);
                        Canvas.SetTop(bullet2, Canvas.GetTop(bullet2) - 10);
                        Canvas.SetTop(bullet3, Canvas.GetTop(bullet3) - 10);

                        // verwijder kogels bij als ze uit scherm zijn
                        if (Canvas.GetTop(bullet1) < 0)
                        {
                            canvas.Children.Remove(bullet1);
                            canvas.Children.Remove(bullet2);
                            canvas.Children.Remove(bullet3);
                            bulletTimer.Stop();
                        }
                    };
                    bulletTimer.Start();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Er is een fout opgetreden bij het afvuren van de shotgun: " + ex.Message);
            }
        }
    }
}