﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace project_OOP
{
    public class MachineGun : Weapon
    {
        public MachineGun() : base(500)
        {
        }

        public override void Fire(Canvas canvas, double x, double y)
        {
            try
            {
                if (CanFire())
                {
                    Image bullet = new Image();
                    bullet.Source = new BitmapImage(new Uri("/bullet.png", UriKind.Relative));
                    bullet.Width = 10;
                    bullet.Height = 10;
                    Canvas.SetTop(bullet, y - bullet.Height);
                    Canvas.SetLeft(bullet, x - bullet.Width / 2);
                    canvas.Children.Add(bullet);

                    lastFired = DateTime.Now;
                    DispatcherTimer bulletTimer = new DispatcherTimer();
                    bulletTimer.Interval = TimeSpan.FromMilliseconds(20);
                    bulletTimer.Tick += (sender, args) =>
                    {
                        Canvas.SetTop(bullet, Canvas.GetTop(bullet) - 10); // Verplaats de kogel omhoog met een snelheid van 5 pixels per tick
                        if (Canvas.GetTop(bullet) < 0) // Als de kogel het bovenste deel van het canvas bereikt wordt hij verwijderd
                        {
                            canvas.Children.Remove(bullet);
                            bulletTimer.Stop();
                        }
                    };
                    bulletTimer.Start();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Er is een fout opgetreden bij het afvuren van het pistool: " + ex.Message);
            }
        }
    }
}
