﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace project_OOP
{
    public abstract class Weapon
    {
        
        protected int fireRate;
        protected DateTime lastFired;

        public Weapon(int fireRate)
        {
            
            this.fireRate = fireRate;
            this.lastFired = DateTime.MinValue;
        }

        public bool CanFire()
        {
            TimeSpan timeSinceLastFired = DateTime.Now - lastFired;
            return timeSinceLastFired.TotalMilliseconds >= fireRate;
        }

        public abstract void Fire(Canvas canvas, double x, double y);
    }
}
