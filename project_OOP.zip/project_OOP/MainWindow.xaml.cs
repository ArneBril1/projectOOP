﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace project_OOP
{
    public partial class MainWindow : Window
    {
        private int score;
        private Random random = new Random();
        private List<Image> enemies = new List<Image>();
        private DispatcherTimer enemyTimer = new DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();
            this.KeyDown += new KeyEventHandler(MainWindow_KeyDown);
            enemyTimer.Interval = TimeSpan.FromSeconds(1);
            enemyTimer.Tick += EnemyTimer_Tick;
            enemyTimer.Start();
        }
        private void EnemyTimer_Tick(object sender, EventArgs e)
        {
            Image enemy = new Image();
            enemy.Source = new BitmapImage(new Uri("/enemy.png", UriKind.Relative));
            enemy.Width = 50;
            enemy.Height = 50;
            Canvas.SetTop(enemy, 0);
            Canvas.SetLeft(enemy, random.Next(0, (int)(canvas.ActualWidth - enemy.Width)));
            canvas.Children.Add(enemy);
            enemies.Add(enemy);
        }

        private void MainWindow_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Left:
                    if (Canvas.GetLeft(spaceship) > 0)
                        Canvas.SetLeft(spaceship, Canvas.GetLeft(spaceship) - 10);
                    break;
                case Key.Right:
                    if (Canvas.GetLeft(spaceship) < canvas.ActualWidth - spaceship.ActualWidth)
                        Canvas.SetLeft(spaceship, Canvas.GetLeft(spaceship) + 10);
                    break;
                case Key.Up:
                    if (Canvas.GetTop(spaceship) > 0)
                        Canvas.SetTop(spaceship, Canvas.GetTop(spaceship) - 10);
                    break;
                case Key.Down:
                    if (Canvas.GetTop(spaceship) < canvas.ActualHeight - spaceship.ActualHeight)
                        Canvas.SetTop(spaceship, Canvas.GetTop(spaceship) + 10);
                    break;
                default:
                    break;
            }
            CheckCollisions();
        }

        private void CheckCollisions()
        {
            foreach (Image enemy in enemies)
            {
                if (Canvas.GetTop(enemy) > canvas.ActualHeight)
                {
                    canvas.Children.Remove(enemy);
                    enemies.Remove(enemy);
                    score++;
                    scoreTextBlock.Text = "Score: " + score;
                    break;
                }

                Rect spaceshipRect = new Rect(Canvas.GetLeft(spaceship), Canvas.GetTop(spaceship), spaceship.ActualWidth, spaceship.ActualHeight);
                Rect enemyRect = new Rect(Canvas.GetLeft(enemy), Canvas.GetTop(enemy), enemy.ActualWidth, enemy.ActualHeight);

                if (spaceshipRect.IntersectsWith(enemyRect))
                {
                    GameOver();
                    break;
                }
            }
        }

        private void GameOver()
        {
            enemyTimer.Stop();
            MessageBox.Show("Game Over. Your Score is " + score);
        }
    }
}