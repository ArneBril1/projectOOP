﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SpaceGame
{
    public partial class MainWindow : Window
    {
        private const int SHIP_SPEED = 5;
        private const int ENEMY_SPEED = 2;
        private const int ENEMY_SPAWN_INTERVAL = 2000;

        private int score = 0;
        private DispatcherTimer gameTimer = new DispatcherTimer();
        private DispatcherTimer enemySpawnTimer = new DispatcherTimer();
        private Ship ship = new Ship();
        private Random random = new Random();
        private string highScoreFilePath = "highscore.txt";


        public MainWindow()
        {
            InitializeComponent();

            highScoreFilePath = Path.Combine(Environment.CurrentDirectory, "highscore.txt");
            random = new Random();
            ship = new Ship();
            canvas.Children.Add(ship.Shape);
            Canvas.SetLeft(ship.Shape, (canvas.Width - ship.Shape.Width) / 2);
            Canvas.SetTop(ship.Shape, canvas.Height - ship.Shape.Height);

            gameTimer = new DispatcherTimer();
            gameTimer.Interval = TimeSpan.FromMilliseconds(16);
            gameTimer.Tick += GameLoop;
            gameTimer.Start();

            enemySpawnTimer = new DispatcherTimer();
            enemySpawnTimer.Interval = TimeSpan.FromMilliseconds(ENEMY_SPAWN_INTERVAL);
            enemySpawnTimer.Tick += SpawnEnemy;
            enemySpawnTimer.Start();

            canvas.Focus();
        }

        private void GameLoop(object sender, EventArgs e)
        {
            MoveShip();
            MoveEnemies();
            CheckCollisions();
        }

        private void MoveShip()
        {
            if (Keyboard.IsKeyDown(Key.Left))
            {
                ship.Move(-SHIP_MOVEMENT_AMOUNT, 0, canvas.Width);
            }
            else if (Keyboard.IsKeyDown(Key.Right))
            {
                ship.Move(SHIP_MOVEMENT_AMOUNT, 0, canvas.Width);
            }
            if (Keyboard.IsKeyDown(Key.Up))
            {
                ship.Move(0, -SHIP_MOVEMENT_AMOUNT, canvas.Width);
            }
            else if (Keyboard.IsKeyDown(Key.Down))
            {
                ship.Move(0, SHIP_MOVEMENT_AMOUNT, canvas.Width);
            }
        }

        private void MoveEnemies()
        {
            foreach (var enemy in canvas.Children)
            {
                if (enemy is Rectangle && ((Rectangle)enemy).Fill == Brushes.Red)
                {
                    ((Enemy)enemy).Move(0, ENEMY_MOVEMENT_AMOUNT);
                }
            }
        }

        private void CheckCollisions()
        {
            foreach (var enemy in canvas.Children)
            {
                if (enemy is Rectangle && ((Rectangle)enemy).Fill == Brushes.Red)
                {
                    Rect enemyRect = new Rect(Canvas.GetLeft((Rectangle)enemy), Canvas.GetTop((Rectangle)enemy), ((Rectangle)enemy).Width, ((Rectangle)enemy).Height);
                    Rect shipRect = new Rect(Canvas.GetLeft(ship.Shape), Canvas.GetTop(ship.Shape), ship.Shape.Width, ship.Shape.Height);
                    if (enemyRect.IntersectsWith(shipRect))
                    {
                        EndGame();
                        return;
                    }
                }
            }
        }

        private void EndGame()
        {
            gameTimer.Stop();
            enemySpawnTimer.Stop();

            if (!File.Exists(highScoreFilePath) || score > int.Parse(File.ReadAllText(highScoreFilePath)))
            {
                File.WriteAllText(highScoreFilePath, score.ToString());
            }

            MessageBox.Show($"Game over! Je score is {score}", "Space Game", MessageBoxButton.OK, MessageBoxImage.Information);
            Close();
        }
    }
}